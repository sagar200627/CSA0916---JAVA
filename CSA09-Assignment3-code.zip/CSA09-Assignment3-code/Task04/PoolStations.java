import java.util.*;
import java.util.concurrent.*;
public class PoolStations {
    static void scan() { try { Thread.sleep(20); } catch (InterruptedException e) {} }   // one script = 20 ms
    public static void main(String[] a) throws Exception {
        // Part 1: four stations on a pool of 2 threads -> thread names show reuse
        ExecutorService ex = Executors.newFixedThreadPool(2);
        List<Future<String>> fs = new ArrayList<>();
        for (int i = 1; i <= 4; i++) { final int id = i;
            fs.add(ex.submit(() -> { scan(); return "Station-" + id + " ran on " + Thread.currentThread().getName(); })); }
        for (Future<String> f : fs) System.out.println(f.get());
        ex.shutdown();

        // Part 2: n = 200 scripts, p threads -> expected about n/p * 20 ms
        int n = 200;
        System.out.println("\nn=200 scripts, 20 ms each (sleep-simulated)");
        for (int p : new int[]{1, 2, 4, 8, 16}) {
            long t0 = System.nanoTime();
            ExecutorService pool = Executors.newFixedThreadPool(p);
            for (int i = 0; i < n; i++) pool.submit(PoolStations::scan);
            pool.shutdown(); pool.awaitTermination(1, TimeUnit.MINUTES);
            long ms = (System.nanoTime() - t0) / 1_000_000;
            System.out.printf("pool p=%2d : %5d ms   (model n/p*20 = %5d ms)%n", p, ms, (n + p - 1) / p * 20);
        }
        // Part 3: manual Thread objects, one per script (p = n) -> creation cost + stacks
        long t0 = System.nanoTime();
        Thread[] ts = new Thread[n];
        for (int i = 0; i < n; i++) { ts[i] = new Thread(PoolStations::scan); ts[i].start(); }
        for (Thread t : ts) t.join();
        System.out.printf("one Thread per script (200 threads): %d ms%n", (System.nanoTime() - t0) / 1_000_000);
    }
}
