import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

class StationThread extends Thread {                       // way 1: extend Thread
    static final AtomicInteger total = new AtomicInteger();
    static final Queue<String> finishOrder = new ConcurrentLinkedQueue<>();
    private final int scripts;
    StationThread(String name, int scripts) { super(name); this.scripts = scripts; }
    @Override public void run() {
        Random rnd = new Random();
        for (int i = 0; i < scripts; i++) {
            try { Thread.sleep(5 + rnd.nextInt(15)); } catch (InterruptedException e) { return; }
            total.incrementAndGet();
        }
        finishOrder.add(getName());
    }
}
class StationTask implements Runnable {                    // way 2: implement Runnable
    private final int scripts; private final String name;
    StationTask(String name, int scripts) { this.name = name; this.scripts = scripts; }
    @Override public void run() {
        Random rnd = new Random();
        for (int i = 0; i < scripts; i++) {
            try { Thread.sleep(5 + rnd.nextInt(15)); } catch (InterruptedException e) { return; }
            StationThread.total.incrementAndGet();
        }
        StationThread.finishOrder.add(name);
    }
}
public class Stations {
    public static void main(String[] args) throws InterruptedException {
        boolean useRunnable = args.length > 0 && args[0].equals("runnable");
        Thread[] st = new Thread[4];
        for (int i = 0; i < 4; i++) {
            String n = "Station-" + (i + 1);
            st[i] = useRunnable ? new Thread(new StationTask(n, 6), n) : new StationThread(n, 6);
        }
        if (args.length == 0 || !args[args.length - 1].equals("quiet"))
            System.out.println("state before start: " + st[0].getState() + ", isAlive=" + st[0].isAlive());
        for (Thread t : st) t.start();
        System.out.println("state after start : " + st[0].getState() + ", isAlive=" + st[0].isAlive());
        Thread.sleep(10);
        System.out.println("state during sleep: " + st[0].getState());
        for (Thread t : st) t.join();
        System.out.println("state after join  : " + st[0].getState() + ", isAlive=" + st[0].isAlive());
        System.out.println("Finish order: " + StationThread.finishOrder);
        System.out.println("Total scanned (printed after join): " + StationThread.total.get());
    }
}
