public class RunVsStart {
    public static void main(String[] a) throws Exception {
        Thread t1 = new Thread(() -> System.out.println("body executed by: " + Thread.currentThread().getName()), "Station-1");
        System.out.println("calling run()  -> "); t1.run();
        Thread t2 = new Thread(() -> System.out.println("body executed by: " + Thread.currentThread().getName()), "Station-2");
        System.out.println("calling start() -> "); t2.start(); t2.join();
        System.out.println("calling start() twice on the same thread:");
        try { t2.start(); } catch (IllegalThreadStateException e) { System.out.println("  " + e); }
        System.out.println("join() missing: total printed too early?");
        int[] total = {0};
        Thread w = new Thread(() -> { try { Thread.sleep(50); } catch (InterruptedException e) {} total[0] = 100; });
        w.start();
        System.out.println("  without join -> total = " + total[0]);
        w.join();
        System.out.println("  with join    -> total = " + total[0]);
    }
}
