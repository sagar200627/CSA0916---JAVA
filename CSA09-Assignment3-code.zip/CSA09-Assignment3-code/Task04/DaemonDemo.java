public class DaemonDemo {
    public static void main(String[] a) throws Exception {
        Thread d = new Thread(() -> {
            for (int i = 1; i <= 10; i++) {
                try { Thread.sleep(100); } catch (InterruptedException e) {}
                System.out.println("daemon Station-3 scanned batch " + i);
            }
            System.out.println("daemon Station-3 FINISHED");
        }, "Station-3");
        d.setDaemon(true);
        d.start();
        Thread.sleep(350);
        System.out.println("main() ends now (daemon isDaemon=" + d.isDaemon() + ")");
    }
}
