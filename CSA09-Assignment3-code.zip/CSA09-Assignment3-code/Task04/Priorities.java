import java.util.*;
import java.util.concurrent.*;
public class Priorities {
    public static void main(String[] a) throws Exception {
        Queue<String> order = new ConcurrentLinkedQueue<>();
        Thread[] t = new Thread[4];
        for (int i = 0; i < 4; i++) {
            final String n = "Station-" + (i + 1);
            t[i] = new Thread(() -> {
                long x = 0;
                for (long k = 0; k < 150_000_000L; k++) x += k;        // CPU-bound work
                if (x == 1) System.out.print("");
                order.add(n);
            }, n);
        }
        t[0].setPriority(Thread.MIN_PRIORITY); t[3].setPriority(Thread.MAX_PRIORITY);
        for (Thread x : t) x.start();
        for (Thread x : t) x.join();
        System.out.println("priority 1,5,5,10 -> " + order);
    }
}
