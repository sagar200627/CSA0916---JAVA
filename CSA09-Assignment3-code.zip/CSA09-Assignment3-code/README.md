# CSA09-<RegisterNumber>-Assignment3
Name: <your name>   Register number: <your register number>   Java: JDK 17+ (tested OpenJDK 21)

Compile and run each task from its folder, e.g.:
    cd Task01 && javac Atm.java && java Atm
Task02: cd stor && javac StorageDemo.java && java StorageDemo   (also portal/, nocause/)
Task05: cd unsync && javac SeatBooking.java && java -Ddelay=true SeatBooking   (also sync/)
Task06: cd tc && javac TokenCounter.java && java TokenCounter   (tcif/ = "if" variant)
Q1 bad/BadOrder.java is meant to FAIL to compile.
Run every program yourself, add screenshots to each folder and commit task by task.
