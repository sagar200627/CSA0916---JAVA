import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.stream.*;

class ScoreException extends Exception {
    ScoreException(String m) { super(m); } ScoreException(String m, Throwable c) { super(m, c); }
}
class MissingFileException extends ScoreException {
    MissingFileException(String f, Throwable c) { super("Missing file " + f, c); }
}
class CorruptFileException extends ScoreException {
    CorruptFileException(String f, String why, Throwable c) { super("Corrupt file " + f + ": " + why, c); }
}
record Result(String file, double average) {}

public class ResultProcessor {
    static int latencyMs = 0;                                    // simulated disk/network delay per file

    /** One unit of work: read, validate, compute. Checked exceptions describe each failure. */
    static Result process(Path p) throws ScoreException {
        try {
            if (latencyMs > 0) Thread.sleep(latencyMs);
            List<String> lines = Files.readAllLines(p);
            if (lines.isEmpty()) throw new CorruptFileException(p.getFileName().toString(), "empty", null);
            String[] parts = lines.get(0).split(",");
            if (parts.length != 4) throw new CorruptFileException(p.getFileName().toString(), "expected 4 fields", null);
            double sum = 0;
            for (int i = 1; i < 4; i++) {
                int s = Integer.parseInt(parts[i].trim());       // NumberFormatException -> corrupt
                if (s < 0 || s > 100) throw new CorruptFileException(p.getFileName().toString(), "score out of range " + s, null);
                sum += s;
            }
            return new Result(p.getFileName().toString(), sum / 3);
        } catch (NoSuchFileException e) {
            throw new MissingFileException(p.getFileName().toString(), e);
        } catch (NumberFormatException e) {
            throw new CorruptFileException(p.getFileName().toString(), "non-numeric score", e);
        } catch (IOException e) {
            throw new ScoreException("I/O error on " + p.getFileName(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ScoreException("interrupted", e);
        }
    }

    static class Summary {
        final ConcurrentHashMap<String, Double> ok = new ConcurrentHashMap<>();        // shared results
        final ConcurrentLinkedQueue<String> failures = new ConcurrentLinkedQueue<>();
        final AtomicInteger missing = new AtomicInteger(), corrupt = new AtomicInteger(), other = new AtomicInteger();
        int total() { return ok.size() + missing.get() + corrupt.get() + other.get(); }
        String line() { return "success=" + ok.size() + " corrupt=" + corrupt + " missing=" + missing + " other=" + other + " total=" + total(); }
    }

    /** Design: ExecutorService + Callable + Future; every Future is resolved, no failure stops the run. */
    static Summary runPool(List<Path> files, int threads) throws Exception {
        Summary s = new Summary();
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        List<Future<Result>> fs = new ArrayList<>(files.size());
        try {
            for (Path p : files) fs.add(pool.submit(() -> process(p)));      // Callable<Result>
            for (int i = 0; i < fs.size(); i++) {
                try {
                    Result r = fs.get(i).get(30, TimeUnit.SECONDS);           // timeout guards a hung task
                    s.ok.put(r.file(), r.average());
                } catch (ExecutionException e) {
                    Throwable c = e.getCause();
                    if (c instanceof MissingFileException) s.missing.incrementAndGet();
                    else if (c instanceof CorruptFileException) s.corrupt.incrementAndGet();
                    else s.other.incrementAndGet();
                    s.failures.add(files.get(i).getFileName() + " -> " + c.getMessage());
                } catch (TimeoutException e) {
                    fs.get(i).cancel(true); s.other.incrementAndGet(); s.failures.add(files.get(i).getFileName() + " -> timeout");
                }
            }
        } finally { pool.shutdown(); }
        return s;
    }

    /** Alternative 1: parallel stream. Failure must be caught INSIDE the lambda, otherwise the whole stream aborts. */
    static Summary runParallelStream(List<Path> files, boolean catchInside) {
        Summary s = new Summary();
        files.parallelStream().forEach(p -> {
            try { Result r = process(p); s.ok.put(r.file(), r.average()); }
            catch (ScoreException e) {
                if (!catchInside) throw new RuntimeException(e);              // what happens with no handling
                if (e instanceof MissingFileException) s.missing.incrementAndGet();
                else if (e instanceof CorruptFileException) s.corrupt.incrementAndGet(); else s.other.incrementAndGet();
            }
        });
        return s;
    }
    /** Alternative 2: one thread per file. */
    static Summary runThreadPerFile(List<Path> files) throws Exception {
        Summary s = new Summary();
        List<Thread> ts = new ArrayList<>();
        for (Path p : files) {
            Thread t = new Thread(() -> {
                try { Result r = process(p); s.ok.put(r.file(), r.average()); }
                catch (ScoreException e) {
                    if (e instanceof MissingFileException) s.missing.incrementAndGet();
                    else if (e instanceof CorruptFileException) s.corrupt.incrementAndGet(); else s.other.incrementAndGet();
                }
            });
            t.start(); ts.add(t);
        }
        for (Thread t : ts) t.join();
        return s;
    }

    static List<Path> generate(Path dir, int n) throws IOException {
        Files.createDirectories(dir);
        List<Path> list = new ArrayList<>(); Random r = new Random(42);
        for (int i = 0; i < n; i++) {
            Path p = dir.resolve(String.format("student%05d.txt", i)); list.add(p);
            int k = i % 50;                                            // 2% corrupt kinds, 2% missing
            if (k == 7)       continue;                                // missing (not created)  -> 200 files
            if (k == 13)      Files.writeString(p, "S" + i + ",80,abc,70\n");          // non-numeric  -> 200
            else if (k == 29) Files.writeString(p, "");                                // empty        -> 200
            else if (k == 41) Files.writeString(p, "S" + i + ",120,50,60\n");          // out of range -> 200
            else Files.writeString(p, "S" + i + "," + r.nextInt(101) + "," + r.nextInt(101) + "," + r.nextInt(101) + "\n");
        }
        return list;
    }

    public static void main(String[] args) throws Exception {
        // ---- Stage 3(c): small hand-checked set -------------------------------------------------
        Path small = Files.createTempDirectory("small");
        Files.writeString(small.resolve("a.txt"), "A,60,70,80\n");
        Files.writeString(small.resolve("b.txt"), "B,100,100,100\n");
        Files.writeString(small.resolve("c.txt"), "C,0,0,0\n");
        Files.writeString(small.resolve("d.txt"), "D,xx,1,2\n");           // corrupt
        Files.writeString(small.resolve("e.txt"), "");                      // corrupt (empty)
        List<Path> sm = Stream.of("a", "b", "c", "d", "e", "f").map(n -> small.resolve(n + ".txt")).collect(Collectors.toList()); // f missing
        Summary hs = runPool(sm, 4);
        System.out.println("Hand-checked set (expected success=3 corrupt=2 missing=1 total=6):");
        System.out.println("  actual  : " + hs.line());
        System.out.println("  averages: " + new TreeMap<>(hs.ok));
        hs.failures.stream().sorted().forEach(f -> System.out.println("  failure : " + f));

        // ---- Full data set ---------------------------------------------------------------------
        Path dir = Files.createTempDirectory("scores");
        List<Path> files = generate(dir, 10_000);
        System.out.println("\nGenerated 10,000 entries: expected success=9200 corrupt=600 missing=200 total=10000");
        System.out.println("Cores available to JVM: " + Runtime.getRuntime().availableProcessors());

        for (int rep = 0; rep < 1; rep++) runPool(files, 4);                 // warm-up
        System.out.println("\nA) Real file reading, no artificial delay (average of 3 runs)");
        for (int p : new int[]{1, 2, 4, 8}) {
            long sum = 0; Summary last = null;
            for (int r = 0; r < 3; r++) { long t0 = System.nanoTime(); last = runPool(files, p); sum += (System.nanoTime() - t0) / 1_000_000; }
            System.out.printf("  pool=%d : %5d ms   %s%n", p, sum / 3, last.line());
        }
        latencyMs = 1;
        System.out.println("\nB) Each file given 1 ms simulated I/O latency (single run each)");
        for (int p : new int[]{1, 2, 4, 8, 16}) {
            long t0 = System.nanoTime(); Summary s = runPool(files, p);
            System.out.printf("  pool=%2d : %5d ms   %s%n", p, (System.nanoTime() - t0) / 1_000_000, s.line());
        }
        latencyMs = 0;

        System.out.println("\nC) Alternatives (no artificial delay unless stated)");
        long t0 = System.nanoTime();
        Summary ps = runParallelStream(files, true);
        System.out.printf("  parallelStream, failure caught inside lambda : %5d ms  %s%n", (System.nanoTime() - t0) / 1_000_000, ps.line());
        try {
            runParallelStream(files, false);
            System.out.println("  parallelStream, no handling: completed (unexpected)");
        } catch (RuntimeException e) {
            System.out.println("  parallelStream, NO handling inside lambda    : ABORTED -> " + e.getCause().getMessage());
        }
        java.lang.management.ThreadMXBean mx = java.lang.management.ManagementFactory.getThreadMXBean();
        mx.resetPeakThreadCount();
        t0 = System.nanoTime();
        try {
            Summary ts = runThreadPerFile(files);
            System.out.printf("  one thread per file                          : %5d ms  %s, peak live threads=%d%n",
                    (System.nanoTime() - t0) / 1_000_000, ts.line(), mx.getPeakThreadCount());
        } catch (Throwable e) { System.out.println("  one thread per file FAILED: " + e); }
        mx.resetPeakThreadCount(); latencyMs = 1;
        t0 = System.nanoTime();
        try {
            Summary ts = runThreadPerFile(files);
            System.out.printf("  one thread per file, 1 ms latency            : %5d ms  %s, peak live threads=%d%n",
                    (System.nanoTime() - t0) / 1_000_000, ts.line(), mx.getPeakThreadCount());
        } catch (Throwable e) { System.out.println("  one thread per file (1 ms) FAILED: " + e); }
        latencyMs = 1;
        t0 = System.nanoTime(); Summary ps2 = runParallelStream(files, true);
        System.out.printf("  parallelStream, 1 ms latency                 : %5d ms  %s (common pool parallelism=%d)%n",
                (System.nanoTime() - t0) / 1_000_000, ps2.line(), ForkJoinPool.commonPool().getParallelism());
    }
}
