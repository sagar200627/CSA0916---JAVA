import java.io.*;

class InsufficientFundsException extends Exception {          // checked: caller must plan for it
    InsufficientFundsException(String m) { super(m); }
}

public class Atm {
    static int balance = 5000;
    static int finallyCount = 0;

    static String withdraw(String cardFile, String acctText, String amtText) {
        try {
            new FileReader(cardFile).close();                 // FileNotFoundException (checked)
            int acct = Integer.parseInt(acctText);            // NumberFormatException (unchecked)
            int amt  = Integer.parseInt(amtText);
            if (amt <= 0)
                throw new IllegalArgumentException("Amount must be positive");   // unchecked
            if (amt > balance)
                throw new InsufficientFundsException("Balance " + balance + ", requested " + amt);
            balance -= amt;
            return "OK: dispensed " + amt + " from account " + acct;
        } catch (FileNotFoundException e) {                   // narrow checked exception first
            return "CATCH#1 FileNotFoundException -> card reader unavailable";
        } catch (NumberFormatException e) {                   // narrower unchecked (subclass of IAE)
            return "CATCH#2 NumberFormatException -> " + e.getMessage();
        } catch (IllegalArgumentException e) {                // broader than NumberFormatException
            return "CATCH#3 IllegalArgumentException -> " + e.getMessage();
        } catch (InsufficientFundsException | IOException e) { // multi-catch: same user-facing handling
            return "CATCH#4 " + e.getClass().getSimpleName() + " -> " + e.getMessage();
        } finally {
            finallyCount++;
            System.out.println("   [finally] card returned, session closed (run #" + finallyCount + ")");
        }
    }

    public static void main(String[] args) {
        String[][] tests = {
            {"cards.txt",   "1001", "500"},    // T1 valid
            {"cards.txt",   "abc",  "500"},    // T2 letters in account
            {"cards.txt",   "1001", "-50"},    // T3 negative amount
            {"cards.txt",   "1001", "9000"},   // T4 more than balance
            {"missing.txt", "1001", "500"},    // T5 card-reader file missing
            {"cards.txt",   "1001", "12.5"},   // T6 decimal typed
        };
        for (int i = 0; i < tests.length; i++) {
            System.out.println("T" + (i + 1) + ": file=" + tests[i][0] + " acct=" + tests[i][1] + " amt=" + tests[i][2]);
            System.out.println("   " + withdraw(tests[i][0], tests[i][1], tests[i][2]));
        }
    }
}
