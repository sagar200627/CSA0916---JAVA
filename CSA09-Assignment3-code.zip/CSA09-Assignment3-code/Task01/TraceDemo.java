public class TraceDemo {
    static void level3(String s) { int x = Integer.parseInt(s); }
    static void level2(String s) { level3(s); }
    static void level1(String s) { level2(s); }
    public static void main(String[] args) { level1("abc"); }
}
