public class CostBench {
    static boolean isInt(String s) {
        if (s.isEmpty()) return false;
        for (int i = 0; i < s.length(); i++) if (!Character.isDigit(s.charAt(i))) return false;
        return true;
    }
    static int viaException(String s) { try { return Integer.parseInt(s); } catch (NumberFormatException e) { return -1; } }
    static int viaCode(String s)      { return isInt(s) ? Integer.parseInt(s) : -1; }
    static int deep(String s, int d)  { return d == 0 ? viaException(s) : deep(s, d - 1); }
    public static void main(String[] a) {
        int N = 1_000_000; long sink = 0;
        for (int w = 0; w < 3; w++) { for (int i = 0; i < 200000; i++) { sink += viaException("abc"); sink += viaCode("abc"); } }
        long t0 = System.nanoTime(); for (int i = 0; i < N; i++) sink += viaException("abc");
        long t1 = System.nanoTime(); for (int i = 0; i < N; i++) sink += viaCode("abc");
        long t2 = System.nanoTime(); for (int i = 0; i < N; i++) sink += viaException("123");
        long t3 = System.nanoTime(); for (int i = 0; i < N; i++) sink += viaCode("123");
        long t4 = System.nanoTime(); for (int i = 0; i < 200000; i++) sink += deep("abc", 50);
        long t5 = System.nanoTime();
        System.out.printf("Invalid input, exception : %6.1f ns/op%n", (t1-t0)/(double)N);
        System.out.printf("Invalid input, error code: %6.1f ns/op%n", (t2-t1)/(double)N);
        System.out.printf("Valid input,   exception : %6.1f ns/op%n", (t3-t2)/(double)N);
        System.out.printf("Valid input,   error code: %6.1f ns/op%n", (t4-t3)/(double)N);
        System.out.printf("Invalid, thrown at stack depth ~50: %6.1f ns/op%n", (t5-t4)/200000.0);
        if (sink == 42) System.out.println();
    }
}
