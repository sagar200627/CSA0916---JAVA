import java.io.*;
public class BadOrder {
    public static void main(String[] args) {
        try {
            new FileReader("x.txt").close();
        } catch (Exception e) {
            System.out.println("general");
        } catch (FileNotFoundException e) {      // unreachable
            System.out.println("specific");
        }
    }
}
