import java.io.File;

public class AtmCodes {              // alternative: no exceptions, error codes
    static int balance = 5000;
    static final int OK = 0, E_NOFILE = -1, E_BADNUM = -2, E_NEG = -3, E_FUNDS = -4;

    static boolean isInt(String s) {
        if (s == null || s.isEmpty()) return false;
        int i = (s.charAt(0) == '-' || s.charAt(0) == '+') ? 1 : 0;
        if (i == s.length()) return false;
        for (; i < s.length(); i++) if (!Character.isDigit(s.charAt(i))) return false;
        return true;
    }
    static int withdraw(String card, String acct, String amt) {
        if (!new File(card).exists()) return E_NOFILE;     // check 1
        if (!isInt(acct) || !isInt(amt)) return E_BADNUM;  // check 2
        int a = Integer.parseInt(amt);
        if (a <= 0) return E_NEG;                           // check 3
        if (a > balance) return E_FUNDS;                    // check 4
        balance -= a;
        return OK;
    }
    public static void main(String[] args) {
        String[][] t = {{"cards.txt","1001","500"},{"cards.txt","abc","500"},{"cards.txt","1001","-50"},
                        {"cards.txt","1001","9000"},{"missing.txt","1001","500"},{"cards.txt","1001","12.5"}};
        for (int i = 0; i < t.length; i++)
            System.out.println("T" + (i+1) + " -> code " + withdraw(t[i][0], t[i][1], t[i][2]));
    }
}
