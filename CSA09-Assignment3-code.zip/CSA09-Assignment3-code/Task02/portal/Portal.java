import java.io.IOException;
import java.util.Set;

class ExamException extends Exception {
    ExamException(String m) { super(m); }
    ExamException(String m, Throwable c) { super(m, c); }
}
class ExamWindowClosedException extends ExamException {          // checked: expected business rule
    ExamWindowClosedException(String m) { super(m); }
}
class NotRegisteredException extends ExamException {              // checked: expected business rule
    NotRegisteredException(String m) { super(m); }
}
class FileTooLargeException extends ExamException {               // checked: caller can ask for smaller file
    FileTooLargeException(String m) { super(m); }
}
class SubmissionStorageException extends ExamException {          // checked wrapper that keeps the cause
    SubmissionStorageException(String m, Throwable c) { super(m, c); }
}
class InvalidSubmissionException extends RuntimeException {       // unchecked: programmer error (null/empty id)
    InvalidSubmissionException(String m) { super(m); }
}

class StorageLayer {
    void write(String student, String file, long kb, boolean diskFull) throws SubmissionStorageException {
        try {
            if (diskFull) throw new IOException("Disk quota exceeded");
            System.out.println("  [storage] saved " + file + " for " + student);
        } catch (IOException e) {
            throw new SubmissionStorageException("Could not store " + file, e);   // chaining
        }
    }
}
class ServiceLayer {
    private final StorageLayer storage = new StorageLayer();
    private final Set<String> registered = Set.of("S101", "S102");
    void submit(String student, String file, long kb, int hour, boolean diskFull, boolean keepCause)
            throws ExamException {
        if (student == null || student.isBlank()) throw new InvalidSubmissionException("student id missing");
        if (hour >= 12) throw new ExamWindowClosedException("Exam window closed at 12:00, submitted at " + hour + ":00");
        if (!registered.contains(student)) throw new NotRegisteredException(student + " is not registered");
        if (kb > 5120) throw new FileTooLargeException(file + " is " + kb + " KB, limit is 5120 KB");
        try {
            storage.write(student, file, kb, diskFull);
        } catch (SubmissionStorageException e) {
            if (keepCause) throw e;                                            // propagate with cause
            throw new SubmissionStorageException("Could not store " + file, null); // cause deliberately lost
        }
    }
}
class Controller {
    private final ServiceLayer service = new ServiceLayer();
    String handle(String student, String file, long kb, int hour, boolean diskFull, boolean keepCause) {
        try {
            service.submit(student, file, kb, hour, diskFull, keepCause);
            return "Submission accepted";
        } catch (ExamWindowClosedException | NotRegisteredException | FileTooLargeException e) {
            return "Rejected: " + e.getMessage();
        } catch (SubmissionStorageException e) {
            return "Sorry, we could not save your answer. Please try again. (ref: " + e.getMessage() + ")";
        } catch (ExamException e) {
            return "Unexpected exam error";
        }
    }
    ServiceLayer service() { return service; }
}

public class Portal {
    public static void main(String[] args) {
        Controller c = new Controller();
        System.out.println("S1 window closed : " + c.handle("S101", "a.pdf", 100, 13, false, true));
        System.out.println("S2 not registered: " + c.handle("S999", "a.pdf", 100, 10, false, true));
        System.out.println("S3 file too large: " + c.handle("S101", "a.pdf", 9000, 10, false, true));
        System.out.println("S4 storage fails : " + c.handle("S101", "a.pdf", 100, 10, true, true));
        System.out.println("S5 valid         : " + c.handle("S102", "b.pdf", 200, 10, false, true));
        try { c.handle(" ", "a.pdf", 1, 10, false, true); }
        catch (InvalidSubmissionException e) { System.out.println("S6 unchecked escaped controller: " + e); }

        System.out.println("\n--- Chained stack trace (cause kept) ---");
        try { c.service().submit("S101", "a.pdf", 100, 10, true, true); }
        catch (ExamException e) { e.printStackTrace(System.out); System.out.println("getCause() = " + e.getCause()); }

        System.out.println("\n--- Cause lost on re-throw ---");
        try { c.service().submit("S101", "a.pdf", 100, 10, true, false); }
        catch (ExamException e) { e.printStackTrace(System.out); System.out.println("getCause() = " + e.getCause()); }
    }
}
