import java.util.concurrent.*;
public class Alt {
    static class WN {                       // wait/notifyAll counter, capacity 5
        final int[] b = new int[5]; int c, in, out;
        synchronized void put(int v) throws InterruptedException { while (c == 5) wait(); b[in] = v; in = (in + 1) % 5; c++; notifyAll(); }
        synchronized int take() throws InterruptedException { while (c == 0) wait(); int v = b[out]; out = (out + 1) % 5; c--; notifyAll(); return v; }
    }
    static double timeWN(int n) throws Exception {
        WN q = new WN(); long[] sum = {0};
        Thread p = new Thread(() -> { try { for (int i = 1; i <= n; i++) q.put(i); } catch (InterruptedException e) {} });
        Thread c = new Thread(() -> { try { for (int i = 1; i <= n; i++) sum[0] += q.take(); } catch (InterruptedException e) {} });
        long t0 = System.nanoTime(); p.start(); c.start(); p.join(); c.join();
        if (sum[0] != (long) n * (n + 1) / 2) throw new AssertionError();
        return (System.nanoTime() - t0) / (double) n;
    }
    static double timeABQ(int n) throws Exception {
        ArrayBlockingQueue<Integer> q = new ArrayBlockingQueue<>(5); long[] sum = {0};
        Thread p = new Thread(() -> { try { for (int i = 1; i <= n; i++) q.put(i); } catch (InterruptedException e) {} });
        Thread c = new Thread(() -> { try { for (int i = 1; i <= n; i++) sum[0] += q.take(); } catch (InterruptedException e) {} });
        long t0 = System.nanoTime(); p.start(); c.start(); p.join(); c.join();
        if (sum[0] != (long) n * (n + 1) / 2) throw new AssertionError();
        return (System.nanoTime() - t0) / (double) n;
    }
    public static void main(String[] a) throws Exception {
        int n = 500_000;
        timeWN(100000); timeABQ(100000);
        double w = 0, q = 0; for (int i = 0; i < 3; i++) { w += timeWN(n); q += timeABQ(n); }
        System.out.printf("wait/notifyAll counter : %7.1f ns per put+take pair (500,000 pairs, avg of 3)%n", w / 3);
        System.out.printf("ArrayBlockingQueue(5)  : %7.1f ns per put+take pair%n", q / 3);
        // sum check using the ABQ version of the assignment's workload
        ArrayBlockingQueue<Integer> bq = new ArrayBlockingQueue<>(5); int[] col = new int[2];
        Thread cook = new Thread(() -> { try { for (int t = 1; t <= 20; t++) bq.put(t); } catch (InterruptedException e) {} });
        Thread[] st = new Thread[2];
        for (int s = 0; s < 2; s++) { final int id = s; st[s] = new Thread(() -> { try { for (int k = 0; k < 10; k++) col[id] += bq.take(); } catch (InterruptedException e) {} }); }
        cook.start(); for (Thread t : st) t.start(); cook.join(); for (Thread t : st) t.join();
        System.out.println("ABQ version: Sum of tokens collected: " + (col[0] + col[1]) + " (expected 210)");
    }
}
