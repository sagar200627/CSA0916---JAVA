import java.util.*;
import java.util.concurrent.*;

/** Capacity-N counter parameterised on notify vs notifyAll, with size recording. */
class Counter {
    final int[] buf; int count, in, out; final boolean all; final List<Integer> sizes = new ArrayList<>();
    int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE;
    Counter(int cap, boolean all) { buf = new int[cap]; this.all = all; }
    synchronized void put(int v) throws InterruptedException {
        while (count == buf.length) wait();
        buf[in] = v; in = (in + 1) % buf.length; count++; rec(); if (all) notifyAll(); else notify();
    }
    synchronized int take() throws InterruptedException {
        while (count == 0) wait();
        int v = buf[out]; out = (out + 1) % buf.length; count--; rec(); if (all) notifyAll(); else notify(); return v;
    }
    private void rec() { min = Math.min(min, count); max = Math.max(max, count); if (sizes.size() < 40) sizes.add(count); }
}
public class Monitor {
    static String run(boolean all, int cap, int producers, int consumers, int perProducer) throws Exception {
        Counter c = new Counter(cap, all);
        int total = producers * perProducer, perConsumer = total / consumers;
        Thread[] ts = new Thread[producers + consumers];
        for (int i = 0; i < producers; i++) { ts[i] = new Thread(() -> { try { for (int k = 0; k < perProducer; k++) c.put(k); } catch (InterruptedException e) {} }); ts[i].setDaemon(true); }
        for (int i = 0; i < consumers; i++) { ts[producers + i] = new Thread(() -> { try { for (int k = 0; k < perConsumer; k++) c.take(); } catch (InterruptedException e) {} }); ts[producers + i].setDaemon(true); }
        for (Thread t : ts) t.start();
        long end = System.currentTimeMillis() + 5000;
        for (Thread t : ts) t.join(Math.max(1, end - System.currentTimeMillis()));
        boolean done = true; for (Thread t : ts) if (t.isAlive()) done = false;
        return (done ? "completed" : "HUNG (threads still waiting after 5 s)") + ", min size=" + c.min + ", max size=" + c.max;
    }
    public static void main(String[] a) throws Exception {
        Counter c = new Counter(5, true);
        Thread p = new Thread(() -> { try { for (int i = 1; i <= 20; i++) c.put(i); } catch (InterruptedException e) {} });
        Thread[] cs = new Thread[2];
        for (int i = 0; i < 2; i++) { cs[i] = new Thread(() -> { try { for (int k = 0; k < 10; k++) { c.take(); Thread.sleep(2);} } catch (InterruptedException e) {} }); }
        p.start(); for (Thread t : cs) t.start(); p.join(); for (Thread t : cs) t.join();
        System.out.println("Counter size after each put/take (first 40 events): " + c.sizes);
        System.out.println("min=" + c.min + " max=" + c.max + "  (must stay within 0..5)\n");
        System.out.println("notifyAll, 2 producers, 3 consumers, capacity 1: " + run(true, 1, 2, 3, 3000));
        for (int i = 1; i <= 3; i++)
            System.out.println("notify(),  2 producers, 3 consumers, capacity 1, trial " + i + ": " + run(false, 1, 2, 3, 3000));
    }
}
