import java.lang.management.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

class Account {
    final int id; int balance; final ReentrantLock lock = new ReentrantLock();
    Account(int id, int balance) { this.id = id; this.balance = balance; }
}
public class Wallet {
    // (1) Deadlock-prone: locks "from" then "to"
    static void transferUnsafe(Account from, Account to, int amt) throws InterruptedException {
        synchronized (from) {
            Thread.sleep(100);                       // widen the window so the deadlock is reliable
            synchronized (to) { from.balance -= amt; to.balance += amt; }
        }
    }
    // (2) Deadlock-free: always lock the account with the smaller id first
    static void transferOrdered(Account from, Account to, int amt) throws InterruptedException {
        Account first = from.id < to.id ? from : to, second = first == from ? to : from;
        synchronized (first) {
            Thread.sleep(100);
            synchronized (second) { from.balance -= amt; to.balance += amt; }
        }
    }
    // (3) Alternative: tryLock with timeout and retry
    static boolean transferTry(Account from, Account to, int amt) throws InterruptedException {
        for (int attempt = 0; attempt < 5; attempt++) {
            if (from.lock.tryLock(50, TimeUnit.MILLISECONDS)) {
                try {
                    Thread.sleep(100);
                    if (to.lock.tryLock(50, TimeUnit.MILLISECONDS)) {
                        try { from.balance -= amt; to.balance += amt; return true; }
                        finally { to.lock.unlock(); }
                    }
                } finally { from.lock.unlock(); }
            }
            Thread.sleep(ThreadLocalRandom.current().nextInt(20, 80));    // back off, then retry
        }
        return false;
    }
    interface Tx { void run(Account a, Account b, int amt) throws Exception; }

    static void scenario(String title, Tx tx, boolean expectDeadlock) throws Exception {
        Account A = new Account(1, 1000), B = new Account(2, 1000);
        Thread t1 = new Thread(() -> { try { tx.run(A, B, 100); } catch (Exception e) {} }, "T1(A->B)");
        Thread t2 = new Thread(() -> { try { tx.run(B, A, 50);  } catch (Exception e) {} }, "T2(B->A)");
        t1.setDaemon(true); t2.setDaemon(true);
        t1.start(); t2.start();
        t1.join(1500); t2.join(1500);
        ThreadMXBean mx = ManagementFactory.getThreadMXBean();
        long[] all = mx.findDeadlockedThreads();
        long[] ids = null;                       // keep only deadlocks that involve THIS scenario's threads
        if (all != null) { for (long id : all) if (id == t1.getId() || id == t2.getId()) { ids = all; break; } }
        System.out.println("== " + title);
        if (ids != null) {
            System.out.println("DEADLOCK detected among " + ids.length + " threads:");
            for (ThreadInfo ti : mx.getThreadInfo(ids)) {
                if (ti.getThreadId() != t1.getId() && ti.getThreadId() != t2.getId()) continue;
                System.out.println("  " + ti.getThreadName() + " BLOCKED, waiting for " + ti.getLockName() + " held by " + ti.getLockOwnerName());
            }
        } else {
            System.out.println("no deadlock; balances A=" + A.balance + " B=" + B.balance + " (sum " + (A.balance + B.balance) + ")");
        }
    }
    public static void main(String[] args) throws Exception {
        scenario("Unsafe transfer (opposite lock order)", Wallet::transferUnsafe, true);
        // new accounts for the next scenarios
        scenario("Lock ordering by account id", Wallet::transferOrdered, false);
        scenario("tryLock with timeout + retry", (a, b, amt) -> transferTry(a, b, amt), false);
        System.exit(0);
    }
}
