import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.*;

interface Booking { boolean book(int seat); }

class Unsafe implements Booking {
    final boolean[] b; Unsafe(int s) { b = new boolean[s]; }
    public boolean book(int s) { if (!b[s]) { Thread.yield(); b[s] = true; return true; } return false; }
}
class SyncMethod implements Booking {
    final boolean[] b; SyncMethod(int s) { b = new boolean[s]; }
    public synchronized boolean book(int s) { if (!b[s]) { b[s] = true; return true; } return false; }
}
class SyncBlock implements Booking {
    final boolean[] b; SyncBlock(int s) { b = new boolean[s]; }
    public boolean book(int s) {
        // only the critical section is locked (validation etc. would stay outside)
        synchronized (this) { if (!b[s]) { b[s] = true; return true; } return false; }
    }
}
class PerSeatLock implements Booking {                 // ReentrantLock per seat
    final boolean[] b; final ReentrantLock[] l;
    PerSeatLock(int s) { b = new boolean[s]; l = new ReentrantLock[s]; for (int i = 0; i < s; i++) l[i] = new ReentrantLock(); }
    public boolean book(int s) { l[s].lock(); try { if (!b[s]) { b[s] = true; return true; } return false; } finally { l[s].unlock(); } }
}
class Cas implements Booking {                          // AtomicBoolean[] + compareAndSet
    final AtomicBoolean[] b; Cas(int s) { b = new AtomicBoolean[s]; for (int i = 0; i < s; i++) b[i] = new AtomicBoolean(); }
    public boolean book(int s) { return b[s].compareAndSet(false, true); }
}
class Chm implements Booking {                          // ConcurrentHashMap.putIfAbsent
    final ConcurrentHashMap<Integer, Boolean> m = new ConcurrentHashMap<>(); Chm(int s) {}
    public boolean book(int s) { return m.putIfAbsent(s, Boolean.TRUE) == null; }
}

public class Variants {
    static int correctness(Booking bk, int seats, int threads) throws Exception {
        AtomicInteger sold = new AtomicInteger();
        Thread[] t = new Thread[threads];
        for (int i = 0; i < threads; i++) { final int seat = i % seats; t[i] = new Thread(() -> { if (bk.book(seat)) sold.incrementAndGet(); }); }
        for (Thread x : t) x.start(); for (Thread x : t) x.join();
        return sold.get();
    }
    static double bench(Booking bk, int seats, int threads, int opsPerThread) throws Exception {
        Thread[] t = new Thread[threads];
        long t0 = System.nanoTime();
        for (int i = 0; i < threads; i++) { final int id = i;
            t[i] = new Thread(() -> { java.util.Random r = new java.util.Random(id); for (int k = 0; k < opsPerThread; k++) bk.book(r.nextInt(seats)); }); }
        for (Thread x : t) x.start(); for (Thread x : t) x.join();
        return (System.nanoTime() - t0) / (double) ((long) threads * opsPerThread);
    }
    public static void main(String[] a) throws Exception {
        String[] names = {"Unsafe", "SyncMethod", "SyncBlock", "PerSeatLock", "Cas", "Chm"};
        java.util.function.IntFunction<Booking>[] mk = new java.util.function.IntFunction[]
            {s -> new Unsafe(s), s -> new SyncMethod(s), s -> new SyncBlock(s), s -> new PerSeatLock(s), s -> new Cas(s), s -> new Chm(s)};
        System.out.println("Correctness: 1000 users compete for 10 seats, 20 trials each (expected sold = 10)");
        for (int k = 0; k < names.length; k++) {
            int bad = 0, max = 0;
            for (int r = 0; r < 20; r++) { int s = correctness(mk[k].apply(10), 10, 1000); if (s != 10) bad++; max = Math.max(max, s); }
            System.out.printf("  %-12s trials with wrong count: %2d/20, max seats sold: %d%n", names[k], bad, max);
        }
        System.out.println("\nTime per booking attempt (ns), 8 threads x 500,000 attempts, s = 1000 seats (average of 3 runs after warm-up)");
        for (int k = 1; k < names.length; k++) {
            bench(mk[k].apply(1000), 1000, 8, 100000);
            double sum = 0; for (int r = 0; r < 3; r++) sum += bench(mk[k].apply(1000), 1000, 8, 500000);
            System.out.printf("  %-12s %7.1f ns%n", names[k], sum / 3);
        }
    }
}
