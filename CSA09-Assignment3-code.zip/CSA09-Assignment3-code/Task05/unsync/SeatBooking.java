public class SeatBooking {
    private final boolean[] booked;
    private int bookingsMade = 0;

    SeatBooking(int seats) { booked = new boolean[seats]; }

    // TODO 1 (first run): WITHOUT synchronized. DELAY widens the gap between check and set.
    static final boolean DELAY = Boolean.getBoolean("delay");
    public void book(int seat) {
        if (!booked[seat]) {                      // CHECK
            if (DELAY) { try { Thread.sleep(1); } catch (InterruptedException e) {} }
            booked[seat] = true;                  // ACT
            bookingsMade++;
        }
    }

    public static void main(String[] args) throws InterruptedException {
        SeatBooking screen = new SeatBooking(10);
        Thread[] users = new Thread[100];
        for (int i = 0; i < users.length; i++) {
            final int seat = i % 10;              // 10 users compete for every seat
            users[i] = new Thread(() -> screen.book(seat));
            users[i].start();
        }
        for (Thread t : users) t.join();
        System.out.println("Seats sold: " + screen.bookingsMade);
    }
}
