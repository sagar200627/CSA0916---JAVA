import java.io.*;
import java.util.*;
import java.util.logging.*;

class TrackedReader implements AutoCloseable {
    static int open = 0;                         // number of handles currently open
    static boolean closeFails = false;           // used for the suppressed-exception demo
    final String name; private final BufferedReader in;
    TrackedReader(String name) throws IOException {
        this.name = name; this.in = new BufferedReader(new FileReader(name)); open++;
    }
    String readLine() throws IOException { return in.readLine(); }
    @Override public void close() throws IOException {
        in.close(); open--;
        if (closeFails) throw new IOException("close() failed for " + name);
    }
}
class TrackedWriter implements AutoCloseable {
    static int open = 0;
    private final PrintWriter out;
    TrackedWriter(String name) throws IOException { out = new PrintWriter(new FileWriter(name)); open++; }
    void println(String s) { out.println(s); }
    @Override public void close() { out.close(); open--; }
}

public class ReportGenerator {
    static final Logger LOG = Logger.getLogger("report");
    static { System.setProperty("java.util.logging.SimpleFormatter.format", "[LOG] %4$s: %5$s%n"); }

    static int total(TrackedReader r) throws IOException {         // parses "item,amount" lines
        int sum = 0; String line;
        while ((line = r.readLine()) != null) sum += Integer.parseInt(line.split(",")[1].trim());
        return sum;
    }

    // Version 1: manual close, NAIVE (close at end of try body, so an exception skips it)
    static String manualNaive(String[] files, String out) {
        try {
            TrackedWriter w = new TrackedWriter(out);
            int grand = 0;
            for (String f : files) {
                TrackedReader r = new TrackedReader(f);
                int s = total(r);
                LOG.info("read " + f + " total=" + s);
                w.println(f + "," + s); grand += s;
                r.close();
            }
            w.println("GRAND," + grand); w.close();
            return "GRAND=" + grand;
        } catch (IOException | RuntimeException e) {
            LOG.severe("failed: " + e);
            return "FAILED";
        }
    }

    // Version 2: manual close in finally (correct but verbose)
    static String manualFinally(String[] files, String out) {
        TrackedWriter w = null; TrackedReader r = null; int grand = 0;
        try {
            w = new TrackedWriter(out);
            for (String f : files) {
                r = new TrackedReader(f);
                int s = total(r);
                LOG.info("read " + f + " total=" + s);
                w.println(f + "," + s); grand += s;
                r.close(); r = null;
            }
            w.println("GRAND," + grand);
            return "GRAND=" + grand;
        } catch (IOException | RuntimeException e) {
            LOG.severe("failed on " + (r != null ? r.name : "?") + ": " + e);
            return "FAILED";
        } finally {
            if (r != null) { try { r.close(); } catch (IOException ignored) {} }
            if (w != null) w.close();
        }
    }

    // Version 3: try-with-resources
    static String withResources(String[] files, String out) {
        int grand = 0; String current = "?";
        try (TrackedWriter w = new TrackedWriter(out)) {
            for (String f : files) {
                current = f;
                try (TrackedReader r = new TrackedReader(f)) {
                    int s = total(r);
                    LOG.info("read " + f + " total=" + s);
                    w.println(f + "," + s); grand += s;
                }
            }
            w.println("GRAND," + grand);
            return "GRAND=" + grand;
        } catch (IOException | RuntimeException e) {
            LOG.severe("failed on " + current + ": " + e);
            return "FAILED";
        }
    }

    static String show() { return "open readers=" + TrackedReader.open + ", open writers=" + TrackedWriter.open; }

    public static void main(String[] args) throws Exception {
        String[] good = {"data/store1.txt", "data/store2.txt", "data/store4.txt"};
        String[] bad  = {"data/store1.txt", "data/store3.txt", "data/store4.txt"};

        System.out.println("== A. Same report from all three versions (valid input) ==");
        System.out.println("manualNaive   : " + manualNaive(good, "r1.txt"));
        System.out.println("manualFinally : " + manualFinally(good, "r2.txt"));
        System.out.println("withResources : " + withResources(good, "r3.txt"));
        System.out.println("r1==r2: " + java.nio.file.Files.readString(java.nio.file.Path.of("r1.txt")).equals(java.nio.file.Files.readString(java.nio.file.Path.of("r2.txt")))
                + ", r2==r3: " + java.nio.file.Files.readString(java.nio.file.Path.of("r2.txt")).equals(java.nio.file.Files.readString(java.nio.file.Path.of("r3.txt"))));
        System.out.println("after valid runs -> " + show());

        System.out.println("\n== B. Failing input (store3.txt has a corrupt amount), one run each ==");
        System.out.println("manualNaive   : " + manualNaive(bad, "x1.txt") + " -> " + show());
        TrackedReader.open = 0; TrackedWriter.open = 0;
        System.out.println("manualFinally : " + manualFinally(bad, "x2.txt") + " -> " + show());
        System.out.println("withResources : " + withResources(bad, "x3.txt") + " -> " + show());

        System.out.println("\n== C. Daily repeat: 400 failing runs of the naive version ==");
        TrackedReader.open = 0; TrackedWriter.open = 0;
        java.util.logging.Logger.getLogger("report").setLevel(java.util.logging.Level.OFF);
        for (int i = 0; i < 400; i++) manualNaive(bad, "x1.txt");
        System.out.println("handles leaked after 400 failing runs: readers=" + TrackedReader.open + ", writers=" + TrackedWriter.open);
        TrackedReader.open = 0; TrackedWriter.open = 0;
        for (int i = 0; i < 400; i++) withResources(bad, "x3.txt");
        System.out.println("try-with-resources after 400 failing runs: " + show());

        System.out.println("\n== D. Suppressed exception ==");
        TrackedReader.closeFails = true;
        try (TrackedReader r = new TrackedReader("data/store3.txt")) {
            total(r);
        } catch (Exception e) {
            System.out.println("primary   : " + e);
            for (Throwable s : e.getSuppressed()) System.out.println("suppressed: " + s);
        }
        TrackedReader.closeFails = false;
    }
}
